from music.models import Author, Song, Album
from django.shortcuts import render
from django.http import HttpResponse
import json
from rest_framework import generics, status
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from rest_framework.response import Response
from music.serializers import AuthorSerializer, SongSerializer


def index(request):
    context = {
        'author_list': Author.objects.all()
    }
    return render(request, 'music/index.html', context)


def author(request, author_id):
    context = {
        'author': Author.objects.filter(id=author_id).first()
    }
    return render(request, 'music/author.html', context)


def song(request):
    song_id = request.GET.get('song_id')
    context = {
        'song': Song.objects.filter(id=song_id).first()
    }
    return render(request, 'music/song.html', context)


def album(request):
    context = {
        'album_list': Album.objects.all()
    }
    return render(request, 'music/album.html', context)


def album_detail(request, album_id):
    context = {
        'album': Album.objects.filter(id=album_id).first()
    }
    return render(request, 'music/album_detail.html', context)


# class AuthorList(APIView):
#     def __create_author_list(self):
#         author_list = list()
#         for author in Author.objects.all():
#             author_data = dict()
#             author_data['name'] = author.name
#             author_data['birth_date'] = author.birth_date.strftime('%d-%m-%Y')
#             author_data['image'] = author.image.url
#             author_list.append(author_data)
#         return author_list
#
#     def post(self, request):
#         return Response(status=status.HTTP_200_OK, data=self.__create_author_list())
#
#     def get(self, request):
#         return Response(status=status.HTTP_200_OK, data=self.__create_author_list())
#
# def author_list(request):
#     authors = Author.objects.all()
#     response_data = list()
#     response_data.append({
#         'method': request.method,
#         'data': request.data
#     })
#     for author in authors:
#         author_data = dict()
#         author_data['name'] = author.name
#         author_data['birth_date'] = author.birth_date.strftime('%d-%m-%Y')
#         author_data['image'] = author.image.url
#         response_data.append(author_data)
#     return Response(status=status.HTTP_200_OK, data=response_data)


class AuthorList(generics.ListAPIView):
    """
    Return list of all Author in the database
    """
    queryset = Author.objects.all()
    serializer_class = AuthorSerializer


class SongList(generics.ListAPIView):
    """
    Display song list of the given author ID.
    """
    serializer_class = SongSerializer

    def get_queryset(self):
        # author_id = self.request.query_params.get('author_id', None)
        author_id = self.kwargs['author_id']
        if author_id is None:
            return Song.objects.none()
        else:
            return Song.objects.filter(author__id=author_id)


class AuthorDetail(generics.RetrieveAPIView):
    serializer_class = AuthorSerializer
    queryset = Author.objects.all()
    lookup_field = 'id'


class AuthorCreate(generics.CreateAPIView):
    serializer_class = AuthorSerializer
    queryset = Author.objects.all()


class SongDetail(generics.RetrieveAPIView):
    serializer_class = SongSerializer
    queryset = Song.objects.all()
    lookup_field = 'name'


class AuthorUpdate(generics.RetrieveAPIView):
    serializer_class = AuthorSerializer
    queryset = Author.objects.all()
    lookup_field = 'id'
