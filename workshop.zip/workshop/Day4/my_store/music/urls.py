from django.urls import path
from music import views

urlpatterns = [
    path('', views.index, name='index'),
    path('author/<int:author_id>/', views.author, name='author'),
    path('song/', views.song, name='song'),
    path('album/', views.album, name='album'),
    path('album_detail/<int:album_id>/', views.album_detail, name='album_detail'),
    #path('author_list/', views.AuthorList.as_view(), name='author_list'),
    path('song_list/<int:author_id>/', views.SongList.as_view()),
    path('author_list/', views.AuthorList.as_view(), name='author_list'),
    path('author_detail/<int:id>/', views.AuthorDetail.as_view(), name='author_detail'),
    path('song_detail/<str:name>/', views.SongDetail.as_view()),
    path('author_create/', views.AuthorCreate.as_view()),
    path('author_update/<int:id>/', views.AuthorUpdate.as_view()),
]
