from django.contrib import admin
from music.models import Author, Song, Album

admin.site.register(Author)
admin.site.register(Song)
admin.site.register(Album)