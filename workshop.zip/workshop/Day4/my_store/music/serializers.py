from music.models import Author, Song
from rest_framework import serializers


class AuthorSerializer(serializers.ModelSerializer):
    birth_date = serializers.DateTimeField(format='%d-%m-%Y')
    number_of_songs = serializers.SerializerMethodField()

    def get_number_of_songs(self, obj):
        return Song.objects.filter(author=obj).count()
    
    class Meta:
        model = Author
        fields = ('id', 'name', 'birth_date', 'image', 'number_of_songs')


class SongSerializer(serializers.ModelSerializer):
    class Meta:
        model = Song
        fields = '__all__'
