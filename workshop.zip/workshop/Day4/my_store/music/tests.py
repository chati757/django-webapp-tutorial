from django.test import TestCase
from rest_framework.test import APIClient
from django.urls import reverse
from music.models import Author
from datetime import datetime
from rest_framework import status


class AuthorTestCase(TestCase):
    def setUp(self):
        self.client = APIClient()
        Author.objects.create(
            name='Dummy Author',
            birth_date=datetime(2010, 8, 11)
        )
        Author.objects.create(
            name='Dummy Author2',
            birth_date=datetime(2009, 8, 11)
        )

    def test_list_author(self):
        response = self.client.get(
            reverse('author_list'),
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 2)
