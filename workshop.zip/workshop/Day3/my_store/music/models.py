from django.db import models


class Author(models.Model):
    "Author class"
<<<<<<< HEAD
    name = models.CharField(max_length=1000)
=======
    name = models.CharField(max_length=500)
>>>>>>> new_branch
    birth_date = models.DateTimeField()
    image = models.ImageField(upload_to='images', null=True)

    def __str__(self):
        return self.name


class Song(models.Model):
    name = models.CharField(max_length=255)
    price = models.IntegerField()
    file = models.FileField(upload_to='songs', null=True)
    author = models.ForeignKey(Author, on_delete=models.CASCADE, related_name='songs')

    def __str__(self):
        return '[%s] %s' % (self.author.name, self.name)


class Album(models.Model):
    name = models.CharField(max_length=255)
    cover = models.ImageField(upload_to='images')
    songs = models.ManyToManyField(Song)

    def __str__(self):
        return self.name
