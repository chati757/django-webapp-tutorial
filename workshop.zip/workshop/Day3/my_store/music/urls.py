from django.urls import path
from music import views

urlpatterns = [
    path('', views.index, name='index'),
    path('author/<int:author_id>/', views.author, name='author'),
    path('song/', views.song, name='song'),
    path('album/', views.album, name='album'),
    path('album_detail/<int:album_id>/', views.album_detail, name='album_detail'),
]
