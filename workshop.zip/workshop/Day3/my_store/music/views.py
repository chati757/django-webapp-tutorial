from music.models import Author, Song, Album
from django.shortcuts import render


def index(request):
    context = {
        'author_list': Author.objects.all()
    }
    return render(request, 'music/index.html', context)


def author(request, author_id):
    context = {
        'author': Author.objects.filter(id=author_id).first()
    }
    return render(request, 'music/author.html', context)


def song(request):
    song_id = request.GET.get('song_id')
    context = {
        'song': Song.objects.filter(id=song_id).first()
    }
    return render(request, 'music/song.html', context)


def album(request):
    context = {
        'album_list': Album.objects.all()
    }
    return render(request, 'music/album.html', context)


def album_detail(request, album_id):
    context = {
        'album': Album.objects.filter(id=album_id).first()
    }
    return render(request, 'music/album_detail.html', context)
