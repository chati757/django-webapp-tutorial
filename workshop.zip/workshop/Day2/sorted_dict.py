items = [{'name':'A', 'age':50}, {'name': 'B', 'age': 10}]

sorted_items = sorted(items, key=lambda i : i['age'])
print(sorted_items)


print(sorted([50, 10], reverse=True))