import time

def time_log(some_function):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = some_function(*args, **kwargs)
        end_time = time.time()
        elapsed_time = end_time - start_time
        print('Function %s takes %f seconds' % (
            some_function.__name__, 
            elapsed_time)
        )
        return result
    return wrapper


@time_log
def acronym_generator(sentence: str)->str:
    acronym = str()
    for word in sentence.split(' '):
        acronym += word[0]
    return acronym.upper()

print(acronym_generator("Portable network graphics"))
