from School import Student, Teacher

s1 = Student('John', 'Snow', 30)
s1.introduce()

s2 = Student('Sansa', 'Stark', 50)
s2.introduce()

s3 = Student('Theon', 'Greyjoy', 70)
s3.introduce()

t = Teacher('Merlin', 'M.')
t.assign_student(s1)
t.assign_student(s2)
t.assign_student(s3)
t.introduce()