class Person:
    def  __init__(self, name):
        self.name = name

    def __str__(self):
        return self.name

    def __repr__(self):
        return str(self)

class Vehicle:
    def __init__(self, name, num_of_wheel, max_passenger):
        self.name = name
        self.num_of_wheel = num_of_wheel
        self.max_passenger = max_passenger

    def travel(self, destination, passenger_list):
        if len(passenger_list) > self.max_passenger:
            raise ValueError('Passenger exceed max limit')
        else:
            # passengers = list()
            # for p in passenger_list:
            #     passengers.append(p.name)
            # List Comprehension
            # passengers = [ p.name for p in passenger_list ]
            print("Travel with %s to %s and passengers %s" % 
                (self.name, destination, str(passenger_list)))


if __name__ == "__main__":
    print('xxxxxxx')







