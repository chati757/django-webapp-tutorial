def calculator(operand, *args):
    if len(args) > 0:
    	result = args[0]
    else:
        raise ValueError('Args is empty!!!')

    for i in args[1:]:
    	if operand == '+':
    		result += i
    	elif operand == '-':
    		result -= i
    	elif operand == '*':
    		result *= i
    	elif operand == '/':
    		result /= i	
    return result

print(calculator('*'))