class A:
    counter = 0
    def __init__(self):
        A.counter += 1


class B(A):
    def print_counter(self):
        print(self.counter)

    def __secret_func(self):
        print("This is secret func")

    def expose_func(self):
        self.__secret_func()


b = B()
b.print_counter()
b.expose_func()