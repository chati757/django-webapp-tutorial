class Clock:
    def __init__(self, hour, minute, **kwargs):
        super().__init__(**kwargs)
        self.hour = hour
        self.minute = minute

    def get_description(self):
        return '%s:%s' % (self.hour, self.minute)

class Calendar:
    def __init__(self, date, month, year, **kwargs):
        super().__init__(**kwargs)
        self.date = date
        self.month = month
        self.year = year

    def get_description(self):
        return '%s/%s/%s' % (
            self.date, self.month, self.year
        )

class Watch(Calendar, Clock):
    def __init__(self, date, month, year, hour, minute):
        super().__init__(
            date = date,
            month = month,
            year = year,
            hour = hour,
            minute = minute
        )

    def get_description(self):
        return '%s %s' % (
            Calendar.get_description(self),
            Clock.get_description(self)
        )

print(Watch(11, 8, 2018, 13, 55).get_description())
