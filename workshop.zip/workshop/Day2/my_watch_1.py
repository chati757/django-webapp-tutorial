class Clock:
    def __init__(self, hour, minute):
        self.hour = hour
        self.minute = minute

    def get_description(self):
        return '%s:%s' % (self.hour, self.minute)

class Calendar:
    def __init__(self, date, month, year):
        self.date = date
        self.month = month
        self.year = year

    def get_description(self):
        return '%s/%s/%s' % (
            self.date, self.month, self.year
        )

class Watch(Calendar, Clock):
    def __init__(self, date, month, year, hour, minute):
        Calendar.__init__(
            self,
            date = date, 
            month = month, 
            year = year
        )
        Clock.__init__(
            self,
            hour = hour, 
            minute = minute
        )

    def get_description(self):
        return '%s %s' % (
            Calendar.get_description(self),
            Clock.get_description(self)
        )

print(Watch(11, 8, 2018, 13, 55).get_description())
