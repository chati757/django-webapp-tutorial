class Car:
  """Car is vehicle it can move to the destination"""
  car_count = 0
  
  def __init__(self, color, model, brand):
    self.color = color
    self.model = model
    self.brand = brand
    Car.car_count += 1
  
  def display_count(self):
    return 'Total car : %d' % Car.car_count

  def display_summary(self):
    return 'Car %s, %s with color %s' % (
      self.brand, self.model, self.color
    )


class Pickup(Car):
  def __init__(self, capacity, *args, **kwargs):
    self.capacity = capacity
    super().__init__(*args, **kwargs)


#p1 = Pickup(200)
p2 = Pickup(200, 'Red', brand='Toyota', model='Vigo')
print(p2.display_summary())
