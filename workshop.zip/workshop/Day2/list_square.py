my_list = [1, 2, 3, 4, 5]

def square(a_list):
  """Test comment"""
  my_list_2 = list()
  for idx, value in enumerate(a_list):
    a_list[idx] = value ** 2
    my_list_2.append(value**2)
  return my_list_2

print("ID of my_list is %s" % id(my_list))
x = square(my_list)
print(x)
print(my_list)
print("ID of x is %s" % id(x))
print(x==my_list)
print(x is my_list)