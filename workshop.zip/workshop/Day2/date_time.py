import datetime

input = "2018-08-17 23:55"

datetime_obj = datetime.datetime.strptime(input, '%Y-%m-%d %H:%M')
print(datetime_obj)

formatted_datetime = datetime_obj.strftime('%a %d %b %Y @ %I.%M %p')
print(formatted_datetime)