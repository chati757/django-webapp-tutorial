def my_func(name: str, age: int) -> str:
    return ('Input name : %s and age : %s' % (name, age))


print(my_func('John', 'xxx'))