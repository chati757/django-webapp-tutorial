class A:
    def who_am_i(self):
        print("I'm A")

class B:
    def who_am_i(self):
        print("I'm B")

class C(A, B):
    pass

C().who_am_i()
