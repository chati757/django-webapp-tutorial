class Person:
    def __init__(self, first_name, last_name):
        self.first_name = first_name
        self.last_name = last_name

    def introduce(self):
        print('Hello, My name is %s %s' % (self.first_name, self.last_name))


class Student(Person):
    def __init__(self, first_name, last_name, grade):
        super().__init__(first_name, last_name)
        self.grade = grade

    def introduce(self):
        print("Hi, I'm a student %s %s with grade %s" % 
            (self.first_name, self.last_name, self.grade)
        )

class Teacher(Person):
    def __init__(self, first_name, last_name):
        super().__init__(first_name, last_name)
        self.student_list = list()

    def assign_student(self, student):
        self.student_list.append(student)

    def introduce(self):
        print("Hello, I'm a teacher. This is my student")
        for student in self.student_list:
            print("%s %s" % (
                    student.first_name, 
                    student.last_name
                ))


s1 = Student('John', 'Snow', 'A')
s1.introduce()

s2 = Student('Sansa', 'Stark', 'B')
s2.introduce()

s3 = Student('Theon', 'Greyjoy', 'B')
s3.introduce()

t = Teacher('Harry', 'Potter')
t.assign_student(s1)
t.assign_student(s2)
t.assign_student(s3)
t.introduce()











