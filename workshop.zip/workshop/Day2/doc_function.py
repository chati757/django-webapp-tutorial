"""
    List square function module
"""

def square(a_list):
    """
    Increase value of every element in a_list by multiple of 2.
    This function will return same list object.

    :param list a_list: The target list to be increased
    :return: Increased value list
    :rtype: list
    """
    for idx, value in enumerate(a_list):
        a_list[idx] = value ** 2
    return a_list