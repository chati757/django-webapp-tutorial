def my_decorator(some_function):
    def wrapper():
        print("Before")
        some_function()
        print("After")

    return wrapper


def my_func():
    print("This is my function")


wrapper = my_decorator(my_func)
wrapper()