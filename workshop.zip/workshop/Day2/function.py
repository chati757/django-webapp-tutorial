def my_func(*args, **kwargs):
    # print("Name : %s" % name)
    print("Args : %s" % str(args))
    print("Kwargs : %s" % str(kwargs))
    print(kwargs['address']['a'])


my_dict = {'a':10, 'b':20}
my_func("John", "Smith", "xxxx",
    age=[1, 2], address={'a':1, 'b':2})
