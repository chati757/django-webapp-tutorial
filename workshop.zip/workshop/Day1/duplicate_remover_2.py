my_list = ['cat', 'dog', 'rat', 'bat']
my_char = 'a'

for idx, word in enumerate(my_list):
    if my_char in word:
        new_word = str()
        for j in word:
            if j != my_char:
                new_word += j
        my_list[idx] = new_word

print(my_list)