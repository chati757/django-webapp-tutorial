import traceback

num_str = input("Please enter the number : ")
try:
    num = int(num_str)
except Exception as ex:
    print("Input is not a number", "TEST", "S2", ex)
else:
    if num % 3 == 0 and num % 5 == 0:
        print("FizzBuzz")
    elif num % 3 == 0:
        print("Fizz")
    elif num % 5 == 0:
        print("Buzz")
    else:
        print(num)