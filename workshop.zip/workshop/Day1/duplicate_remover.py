input = [1, 2, 3, 4, 5, 5, 4, 3, 2, 1]
output = list()

for i in input:
    if not i in output:
        output.append(i)

print(output)