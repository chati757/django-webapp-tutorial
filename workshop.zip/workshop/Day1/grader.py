summary = {'A': 0, 'B': 0, 'C': 0, 'D': 0, 'E': 0}
is_running = True
while is_running:
    input_txt = input("Please enter number 0-100 and enter 'q' to quit: ")
    if input_txt == 'q':
        is_running = False
        continue

    try:
        score = int(input_txt)
    except:
        print('Invalid input score %s' % input_txt)
        continue

    if score > 0 and score < 50:
        summary['E'] += 1
    elif score >= 50 and score < 60:
        summary['D'] += 1
    elif score >= 60 and score < 70:
        summary['C'] += 1
    elif score >= 70 and score < 80:
        summary['B'] += 1
    elif score >= 80 and score <= 100:
        summary['A'] += 1
    else:
        print('Invalid input score %s' % input_txt)

for key, value in summary.items():
    print('Grade %s : %s' % (key, value))